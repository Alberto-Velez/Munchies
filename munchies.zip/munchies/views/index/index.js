
var main = function(){

$(".drop").click(function(){
$(".cssmenu").css("display", "block");
$(".row1").css("height","90px")
})



$(window).resize(function(){

       if ($(window).width() <= 800 ){


       }



});
};

$(document).ready(main);
