
var main = function(){



  $(".drop").click(function(){
  $(".cssmenu").css("display", "block");
  $(".row1").css("height","90px")
  })

$(".salads").hide();
$(".snacks").hide();
$(".sandwich").hide();
$(".sitems").hide();

$(".b").click(function(){

$(".burgers").slideDown('slow');
$(".salads").hide();
$(".snacks").hide();
$(".sandwich").hide();
$(".sitems").hide();



});


$(".sa").click(function(){

  $(".salads").slideDown('slow');
  $(".burgers").hide();
  $(".snacks").hide();
  $(".sandwich").hide();
  $(".sitems").hide();

});


$(".sh").click(function(){

  $(".sitems").slideDown('slow');
  $(".burgers").hide();
  $(".snacks").hide();
  $(".sandwich").hide();
  $(".salads").hide();

});



$(".sn").click(function(){

  $(".snacks").slideDown('slow');
  $(".burgers").hide();
  $(".salads").hide();
  $(".sandwich").hide();
  $(".sitems").hide();

});

$(".san").click(function(){

  $(".sandwich").slideDown('slow');
  $(".burgers").hide();
  $(".salads").hide();
  $(".sitems").hide();
  $(".snacks").hide();

});




};

$(document).ready(main);
